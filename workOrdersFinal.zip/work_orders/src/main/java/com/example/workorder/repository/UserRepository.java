package com.example.workorder.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.workorder.model.UserDetails;

public interface UserRepository extends CrudRepository<UserDetails, Integer> {

	


	
	@Query(value = "SELECT * From user where roleId = :name",nativeQuery = true)
	Iterable<UserDetails> findBySoftwareId(@Param("name") Iterable<Integer> softwareRole);

	@Query(value = "SELECT firstName from user u where roleId = :name",nativeQuery = true)
	List<Object[]> findSoftware(@Param("name") Iterable<Integer> softwareRole);
	
}
