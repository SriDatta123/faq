package com.example.workorder.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.workorder.model.Work_Orders_History;



public interface Work_Orders_HistoryRepository extends  CrudRepository<Work_Orders_History, Integer>{

	@Query(value = "SELECT * From work_orders_history where createdBy = :id",nativeQuery = true)
	Iterable<Work_Orders_History> getWorkHistoryByUserName(@Param("id") String softwareRole);

	@Query(value = "SELECT woId From work_orders_history where createdBy = :id",nativeQuery = true)
	Iterable<Integer> getWorkIdByUserName(@Param("id") int softwareRole);
	
	
	@Query(value = "SELECT u.woStatus,count(*) as controlRunCount from work_orders_history u where u.woStatus IS NOT NULL group by u.woStatus ",nativeQuery = true)
	List<Object[]> findCountWoStatus();
	
	
	@Query(value = "SELECT u.devStatus,count(*)  as controlRunCount from work_orders_history u where u.devStatus IS NOT NULL group by u.devStatus ",nativeQuery = true)
	List<Object[]> findCountDevStatus();
}
