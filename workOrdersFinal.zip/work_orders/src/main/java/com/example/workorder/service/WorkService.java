package com.example.workorder.service;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.workorder.model.*;
import com.example.workorder.repository.*;





@Service  
public class WorkService {
	
	@Autowired 
	Work_OrdersRepository workrepo;
	
	@Autowired 
	Work_Orders_HistoryRepository workhistoryrepo;
	
	public List<Work_Orders> getAllWorks()   
	{  
	List<Work_Orders> works = new ArrayList<Work_Orders>();  
	workrepo.findAll().forEach(works1 -> works.add(works1));  
	return works;  
	}   
	
	public void saveOrUpdate(Work_Orders workodd)   
	{  
		workrepo.save(workodd);  
	}  
 
	public void delete(int id)   
	{  
		workrepo.deleteById(id);  
	}  
	public void update(Work_Orders works, int worksid)   
	{  
		workrepo.save(works);  
	}  
	
	//WorkOrdersHistory table services
	
	public List<Work_Orders_History> getAllWorks2()   
	{  
	List<Work_Orders_History> works = new ArrayList<Work_Orders_History>();  
	workhistoryrepo.findAll().forEach(works1 -> works.add(works1));  
	return works;  
	}  
	
	public void saveOrUpdate2(Work_Orders_History workodd)   
	{  
		workhistoryrepo.save(workodd);  
	}  
 
	public void delete2(int id)   
	{  
		workhistoryrepo.deleteById(id);  
	}  
	public void update2(Work_Orders_History works, int worksid)   
	{  
		workhistoryrepo.save(works);  
	}  
	
	
	
	
}
