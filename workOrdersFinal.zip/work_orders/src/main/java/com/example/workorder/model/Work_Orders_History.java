package com.example.workorder.model;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "work_orders_history")
public class Work_Orders_History {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	
	@Column(name="woId")
	private int woId;
	

    @Column(name="assignedTo")
	private String assignedTo;
    
	
    @Column(name="createdBy")
	private String createdBy;
    
	@JsonFormat(pattern="yyyy-MM-dd")
    @Column(name="createdTime")
	private Date createdTime;
	
    @Column(name="modifiedBy")
	private String modifiedBy;
    
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name="modifiedTime")
	private Date modifiedTime;
	
	@Column(name="comments")
	private String comments;
	
	

	
	
	
	
	
	@Enumerated(EnumType.STRING)
	@Column(name="woStatus")
	public woStatus woStatus;

	public enum woStatus{
		Open,Accepted,Rejected,Completed,In_Progress,On_Hold
	}


	@Enumerated(EnumType.STRING)
	@Column(name="devStatus")
	public devStatus devStatus;

	public enum devStatus{
		Open,Completed,Testing,Assigned,Deployed,In_Progress
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getWoId() {
		return woId;
	}


	public void setWoId(int woId) {
		this.woId = woId;
	}


	public String getAssignedTo() {
		return assignedTo;
	}


	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}





	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedTime() {
		return modifiedTime;
	}


	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public woStatus getWoStatus() {
		return woStatus;
	}


	public void setWoStatus(woStatus woStatus) {
		this.woStatus = woStatus;
	}


	public devStatus getDevStatus() {
		return devStatus;
	}


	public void setDevStatus(devStatus devStatus) {
		this.devStatus = devStatus;
	}





	
	
	
	
	

}






