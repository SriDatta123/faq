package com.example.workorder.controller;


import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.workorder.model.JoinTable;
import com.example.workorder.model.UserDetails;
import com.example.workorder.model.Work_Orders;
import com.example.workorder.model.Work_Orders_History;
import com.example.workorder.repository.JoinTableRepository;
import com.example.workorder.repository.RoleRepository;
import com.example.workorder.repository.UserRepository;
import com.example.workorder.repository.Work_OrdersRepository;
import com.example.workorder.repository.Work_Orders_HistoryRepository;
import com.example.workorder.service.WorkService;


@CrossOrigin
@RestController  
public class Controller {

	@Autowired
	WorkService workServ; 
	

	
	@Autowired 
	RoleRepository roleRepo;
	
	@Autowired 
	UserRepository userRepo;
	
	@Autowired 
	Work_OrdersRepository workRepo;
	
	@Autowired 
	Work_Orders_HistoryRepository workHistoryRepo;
	
	@Autowired 
	JoinTableRepository joinTableRepo;
	

	@GetMapping("/workShow")  
	private List<Work_Orders> getAllWorks()   
	{  
		return workServ.getAllWorks();  
	}  

	@PostMapping("/workAdd")  
	private int saveWork(@RequestBody Work_Orders works)   
	{  
		workServ.saveOrUpdate(works);  
		return works.getWoId();  

	}  
	@PutMapping("/workUpdate")  
	private Work_Orders update(@RequestBody Work_Orders works)   
	{  
		workServ.saveOrUpdate(works);  
		return works;  
	}  
	
	
	@DeleteMapping("/workDelete")  
	private Work_Orders delete(@RequestBody Work_Orders works)   
	{  
		workServ.delete(works.getWoId());  
		return works;  
	}  


	//Workordershistory

	@GetMapping("/workHistoryShow")  
	private List<Work_Orders_History> getAllWorks2()   
	{  
		return workServ.getAllWorks2();  
	}  

	@PostMapping("/workHistoryAdd")  
	private int saveWork2(@RequestBody Work_Orders_History works)   
	{  
		workServ.saveOrUpdate2(works);  
		return works.getWoId();  
	}  
	@PutMapping("/workHistoryUpdate")  
	private Work_Orders_History update2(@RequestBody Work_Orders_History works)   
	{  
		workServ.saveOrUpdate2(works);  
		return works;  
	}  

	@DeleteMapping("/workHistoryDelete")  
	private Work_Orders_History delete2(@RequestBody Work_Orders_History works)   
	{  
		workServ.delete2(works.getWoId());  
		return works;  
	}  
	
	//UserTable

	
	@GetMapping("/role")  
	private Iterable<UserDetails> getRoles()   
	{  
		return userRepo.findBySoftwareId(roleRepo.softwareRole());
	} 
	
	//Get user details by id in requestbody json format {"id" : 12}
	@GetMapping("/UserDetails")  
	private Optional<UserDetails> getUserDetails(@RequestBody UserDetails u)   
	{  

		return userRepo.findById(u.getId());
	} 
	
	
	
	//User specific data
	@GetMapping("/workOrdersSpecific")  
	private Iterable<Work_Orders> getById1(@RequestBody Work_Orders u)   
	{  
		return workRepo.getWorkByUserName(u.getCreatedBy());
	} 
	@GetMapping("/workOrdersHistorySpecific")  
	private Iterable<Work_Orders_History> getById2(@RequestBody Work_Orders_History u)   
	{  
		return workHistoryRepo.getWorkHistoryByUserName(u.getCreatedBy());
	} 
	
	
	//Joined Two Tables
	@GetMapping("/workShowAll")
	private Iterable<JoinTable> getWorkTest()
	{

		return joinTableRepo.findAll();

	}

	
	//Joined Two Tables
	@GetMapping("/workShowAllSpecific")
	private Iterable<JoinTable> getWorkTest2(@RequestBody Work_Orders u)
	{
		return joinTableRepo.findAllById(workRepo.getWorkIdByUserName(u.getCreatedBy()));
	
	}
	
	
	
	//count
	@GetMapping("/countWoStatus")
	private Map<String,BigInteger> getCountWoStatus(){
	    HashMap<String, BigInteger> c = new HashMap<String, BigInteger>();

		List<Object[]> list = workRepo.findCountWoStatus();
		for (Object[] ob : list){
		    String serverName = (String)ob[0];
		    BigInteger count = (BigInteger)ob[1];
		    c.put(serverName, count);
		    
		}
		
		return c;
		
	}
	//count
		@GetMapping("/countDevStatus")
		private Map<String,BigInteger> getCountDevStatus(){
		    HashMap<String, BigInteger> c = new HashMap<String, BigInteger>();

			List<Object[]> list = workHistoryRepo.findCountDevStatus();
			for (Object[] ob : list){
			    String serverName = (String)ob[0];
			    BigInteger count = (BigInteger)ob[1];
			    c.put(serverName, count);
			    
			}
			
			return c;
		}
	
	//Post into two tables
		@PutMapping("/updateAll")
		private Iterable<JoinTable> getWorkTest3(@RequestBody JoinTable u)
		{
//			int woid = u.getWoId();
			List<Work_Orders_History> woid = u.getWorkOrdersHistory();
			Work_Orders_History w = woid.get(0);
			w.getWoId();
			workHistoryRepo.save(w);
			return null;
			
		}

		
		@GetMapping("/role2")  
		private Iterable<UserDetails> getRoles2()   
		{  
			return userRepo.findBySoftwareId(roleRepo.softwareRole());
		} 
	
	
}
