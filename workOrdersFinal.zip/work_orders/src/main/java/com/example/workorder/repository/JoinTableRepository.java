package com.example.workorder.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.workorder.model.JoinTable;

public interface JoinTableRepository extends  CrudRepository<JoinTable, Integer> {

}
