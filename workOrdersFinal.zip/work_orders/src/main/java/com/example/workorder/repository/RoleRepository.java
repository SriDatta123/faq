package com.example.workorder.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.workorder.model.Role;


public interface RoleRepository extends CrudRepository<Role, Integer> {

	@Query(value = "SELECT roleId from role where name = 'Software'",nativeQuery = true)
	Iterable<Integer> softwareRole();
}
