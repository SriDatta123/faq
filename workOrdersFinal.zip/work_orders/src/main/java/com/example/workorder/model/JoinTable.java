package com.example.workorder.model;
import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import javax.persistence.Table;



@Entity
@Table(name = "work_orders")
public class JoinTable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int woId;
	@Column(name="RequirementName")
	private String requirementName;
	private String description;
	private String contactName;
	private String  contactNumber;
	private String contactEmail;
	private Date createdTime;
	private String modifiedBy;
	private Date modifiedTime;
	private String comments;
	private String createdBy;

	




	@Enumerated(EnumType.STRING)
	@Column(name="woStatus")
	public woStatus woStatus;

	public enum woStatus{
		Open,Accepted,Rejected,Completed,In_Progress,On_Hold
	}



	@Enumerated(EnumType.STRING)
	@Column(name="applSource")
	public applSource applSource;

	public enum applSource{
		Heartbeat,Workspace,Monitoring,Procurement,Site_Manager

	}

	@Enumerated(EnumType.STRING)
	@Column(name="priority")
	public priority priority;

	public enum priority{
		High,Medium,Low

	}
	@Enumerated(EnumType.STRING)
	@Column(name="typeOfProblem")
	public typeOfProblem typeOfProblem;

	public enum typeOfProblem{
		Bug,Enhancement,New

	}

	@Enumerated(EnumType.STRING)
	@Column(name="noOfTimesOccurred")
	public noOfTimesOccurred noOfTimesOccurred;

	public enum noOfTimesOccurred{
		GreaterThan10,GreaterThan50

	}

	
	
	
	
	

	
	private byte[] file;

	private String fileName;





	public int getWoId() {
		return woId;
	}





	public void setWoId(int woId) {
		this.woId = woId;
	}





	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getContactName() {
		return contactName;
	}


	public void setContactName(String contactName) {
		this.contactName = contactName;
	}




	public String getContactNumber() {
		return contactNumber;
	}





	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}





	public String getContactEmail() {
		return contactEmail;
	}


	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}


	public Date getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedTime() {
		return modifiedTime;
	}


	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}






	public woStatus getWoStatus() {
		return woStatus;
	}


	public void setWoStatus(woStatus woStatus) {
		this.woStatus = woStatus;
	}


	public applSource getApplSource() {
		return applSource;
	}


	public void setApplSource(applSource applSource) {
		this.applSource = applSource;
	}


	public priority getPriority() {
		return priority;
	}


	public void setPriority(priority priority) {
		this.priority = priority;
	}


	public typeOfProblem getTypeOfProblem() {
		return typeOfProblem;
	}


	public void setTypeOfProblem(typeOfProblem typeOfProblem) {
		this.typeOfProblem = typeOfProblem;
	}


	public noOfTimesOccurred getNoOfTimesOccurred() {
		return noOfTimesOccurred;
	}


	public void setNoOfTimesOccurred(noOfTimesOccurred noOfTimesOccurred) {
		this.noOfTimesOccurred = noOfTimesOccurred;
	}


	public byte[] getFile() {
		return file;
	}


	public void setFile(byte[] file) {
		this.file = file;
	}


	public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}





	

	
	public String getRequirementName() {
		return requirementName;
	}


	public void setRequirementName(String requirementName) {
		this.requirementName = requirementName;
	}
	
	
	
	


	
	
	

	
	@OneToMany(targetEntity = Work_Orders_History.class ,fetch = FetchType.EAGER)
	@JoinColumn(name="woId",referencedColumnName="woId")
	private List<Work_Orders_History> workOrdersHistory;





	public List<Work_Orders_History> getWorkOrdersHistory() {
		return workOrdersHistory;
	}





	public void setWorkOrdersHistory(List<Work_Orders_History> workOrdersHistory) {
		this.workOrdersHistory = workOrdersHistory;
	}





	public String getCreatedBy() {
		return createdBy;
	}





	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}









	
	






	




	
	
	
}






