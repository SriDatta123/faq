package com.example.workorder.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.workorder.model.Work_Orders;



public interface Work_OrdersRepository extends  CrudRepository<Work_Orders, Integer>{

	
	
	@Query(value = "SELECT * From work_orders where createdBy = :id",nativeQuery = true)
	Iterable<Work_Orders> getWorkByUserName(@Param("id") String softwareRole);
	
	@Query(value = "SELECT woId From work_orders where createdBy = :id",nativeQuery = true)
	Iterable<Integer> getWorkIdByUserName(@Param("id") String createdBy);
	
	
	@Query(value = "SELECT u.woStatus,count(*) as controlRunCount from work_orders u  where u.woStatus IS NOT NULL group by u.woStatus",nativeQuery = true)
	List<Object[]> findCountWoStatus();



}
